package EPAM.NewYearGift;

public class Eclairs extends Chocolate{
	
	Eclairs()
	{
		defineWeight();
		defineName();
	}
	public void defineWeight()
	{
		weight= 5;
	}
	
	public void defineName()
	{
		name="Eclairs";
	}
	
}