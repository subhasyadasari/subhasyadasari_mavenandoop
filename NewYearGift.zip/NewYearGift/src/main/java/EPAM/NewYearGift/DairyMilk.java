package EPAM.NewYearGift;

public class DairyMilk extends Chocolate{
	
	DairyMilk()
	{
		defineWeight();
		defineName();
	}
	public void defineWeight()
	{
		weight= 15;
	}
	
	public void defineName()
	{
		name="DairyMilk";
	}
	
}