package EPAM.NewYearGift;

public class Kova extends Sweet{
	
	Kova ()
	{
		defineWeight();
		defineName();
	}
	public void defineWeight()
	{
		weight= 10;
	}
	
	public void defineName()
	{
		name="Kova";
	}
	
}
