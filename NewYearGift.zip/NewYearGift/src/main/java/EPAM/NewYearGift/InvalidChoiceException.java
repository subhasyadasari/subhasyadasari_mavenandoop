package EPAM.NewYearGift;

public class InvalidChoiceException extends Exception {
	InvalidChoiceException(String s) {
		super(s);
	}
}
