package EPAM.NewYearGift;

public class Chocolate extends NewYearGift{
	
	Chocolate()
	{
		defineWeight();
		defineName();
	}
	public void defineWeight()
	{
		weight= 0;
	}
	
	public void defineName()
	{
		name="Chocolate";
	}
	

}
