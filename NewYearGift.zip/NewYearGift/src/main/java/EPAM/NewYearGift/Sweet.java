package EPAM.NewYearGift;

public class Sweet extends NewYearGift{
	
	Sweet()
	{
		defineWeight();
		defineName();
	}
	
	public void defineWeight()
	{
		weight= 0;
	}
	
	public void defineName()
	{
		name="Sweet";
	}
	
	

}
