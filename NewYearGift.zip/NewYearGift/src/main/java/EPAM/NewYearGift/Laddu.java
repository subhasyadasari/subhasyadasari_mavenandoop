package EPAM.NewYearGift;

public class Laddu extends Sweet{
	
	Laddu()
	{
		defineWeight();
		defineName();
	}
	public void defineWeight()
	{
		weight= 25;
	}
	
	public void defineName()
	{
		name="Laddu";
	}
	
}